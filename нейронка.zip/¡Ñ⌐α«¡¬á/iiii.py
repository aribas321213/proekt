mas={}
for f in range(99):
    z=input()
    