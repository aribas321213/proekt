r=int(input())
print(r*2+1)